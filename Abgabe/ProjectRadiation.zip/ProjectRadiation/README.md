# ProjectRadiation

An app that measures the solar radiation and the amount of pollen you are exposed to.

My work process: [drive](https://drive.google.com/drive/folders/1_Lk1UPp1nMLZOAIgFx59xXLB8oCOxPej?usp=sharing)
