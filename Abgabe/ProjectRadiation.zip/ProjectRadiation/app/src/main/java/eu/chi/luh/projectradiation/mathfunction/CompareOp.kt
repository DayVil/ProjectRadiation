package eu.chi.luh.projectradiation.mathfunction

enum class CompareOp {
    GREATER,
    LESSER
}