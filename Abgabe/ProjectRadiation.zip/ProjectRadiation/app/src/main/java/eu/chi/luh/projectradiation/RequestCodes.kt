package eu.chi.luh.projectradiation

class RequestCodes {
    companion object {
        const val PERMISSION_REQUEST_ACCESS_LOCATION = 100
    }
}